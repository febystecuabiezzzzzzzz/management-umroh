import Sidebar from '@/components/Sidebar';
export default function DashboardLayout({children}:{children:React.ReactNode}){return <div className="app"><Sidebar/><main className="main"><header className="topbar"><b>Manajemen Umroh</b><span className="label">Administrator ▾</span></header>{children}</main></div>}
