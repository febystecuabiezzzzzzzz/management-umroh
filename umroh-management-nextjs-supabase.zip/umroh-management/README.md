# Umroh Management

Starter aplikasi manajemen umroh profesional berbasis Next.js + Supabase.

## Jalankan

1. Ekstrak ZIP.
2. Pastikan Node.js 20+ terpasang.
3. Jalankan `npm install`.
4. Salin `.env.example` menjadi `.env.local`.
5. Isi `NEXT_PUBLIC_SUPABASE_URL` dan `NEXT_PUBLIC_SUPABASE_ANON_KEY`.
6. Buka Supabase SQL Editor, jalankan `supabase/schema.sql`.
7. Jalankan `npm run dev`.
8. Buka http://localhost:3000

## Catatan

UI dashboard dan struktur modul sudah disiapkan. Modul CRUD produksi, authentication flow, Storage dokumen, RLS berbasis role, invoice, export laporan, dan notifikasi dapat dilanjutkan di atas schema ini.
