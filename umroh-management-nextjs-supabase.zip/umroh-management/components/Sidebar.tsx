import Link from 'next/link';
const items=[['Dashboard','/dashboard'],['Jamaah','/jamaah'],['Paket Umroh','/paket'],['Pendaftaran','/pendaftaran'],['Keuangan','/pembayaran'],['Dokumen','/dokumen'],['Keberangkatan','/keberangkatan'],['Laporan','/laporan']];
export default function Sidebar(){return <aside className="sidebar"><div className="brand">✦ Umroh Management</div><nav className="nav">{items.map(([n,u])=><Link key={u} href={u}>{n}</Link>)}</nav></aside>}
